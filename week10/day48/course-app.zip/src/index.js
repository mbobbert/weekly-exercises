import React from 'react';
import ReactDOM from 'react-dom';
import Course from './course/course.js';
import './index.css'

class App extends React.Component {
	render() {
		return (
			<div>
				<header>
					<div className="container">
						REACT COURSE
					</div>
				</header>
				<main>
					<div className="container">
						<Course name="Introduction to React"/>
					</div>
				</main>
				<footer>
					<div className="container">
						REACT COURSE
					</div>
				</footer>
			</div>
		)
	}
}

ReactDOM.render(
	<App />,
	document.getElementById('app')
)
