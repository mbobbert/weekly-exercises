import React from 'react';
import './course.css';

export default class Course extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			completed: 0 // Number of completed lessons
		};
	}
	
	render() {
		return (
			<div className="course">
				<h1>{this.props.name}</h1>
				<p>
					<strong>Completed lessons {this.state.completed}/5</strong>
				</p>
				<Lesson 
					weekday="Mon" 
					date="12.3" 
					title="What is React?"
					selectCallback={this.onLessonSelect.bind(this)}>
					Today, we're starting out at the beginning. Let's look at what React is and what makes it tick. We'll discuss why we want to use it.
				</Lesson>
				<Lesson 
					weekday="Tue" 
					date="13.3" 
					title="What is JSX?"
					selectCallback={this.onLessonSelect.bind(this)}>
					Now that we know what React is, let's take a look at a few terms and concepts that will come up throughout the rest of the series.
				</Lesson>
				<Lesson 
					weekday="Wed" 
					date="14.3" 
					title="Our First Components"
					selectCallback={this.onLessonSelect.bind(this)}>
					The first two articles in this series were heavy on discussion. In today's session, let's dive into some code and write our first React app.
				</Lesson>
				<Lesson 
					weekday="Thu" 
					date="15.3" 
					title="Complex Components"
					selectCallback={this.onLessonSelect.bind(this)}>
					Awesome, we've built our first component. Now let's get a bit fancier and start building a more complex interface.
				</Lesson>
				<Lesson 
					weekday="Fri" 
					date="16.3" 
					title="Data-Driven"
					selectCallback={this.onLessonSelect.bind(this)}>
					Hard-coding data in our applications isn't exactly ideal. Today, we'll set up our components to be driven by data to them access to external data.
				</Lesson>
			</div>
		)
	}

	// Called when a lesson is selected
	onLessonSelect() {
		this.setState(
			{
				completed: this.state.completed + 1
			}
		);
	}
}

class Lesson extends React.Component {	
	render () {
		return (
			<div className="lesson">
				<DayBox 
					weekday={this.props.weekday}
					date={this.props.date}
					selectCallback={this.props.selectCallback}/>
				<Description 
					title={this.props.title}
					body={this.props.children} />
			</div>
		);
	}
}

class DayBox extends React.Component {	
	constructor(props) {
		super(props);

		this.state = {
			boxColor: '#ec692c'
		};
	}

	render () {
		return (
			<div 
				className="date-box"
				style={{backgroundColor: this.state.boxColor}}
				onClick={this.handleClick.bind(this)}>
				<div className="weekday">
					{this.props.weekday}
				</div>
				<div className="date">
					{this.props.date}
				</div>
			</div>
		);
	}

	handleClick() {
		this.setState(
			{
				boxColor: 'darkblue'
			}
		);

		this.props.selectCallback();
	}
}

class Description extends React.Component {	
	render () {
		return (
			<div className="description">
				<div className="desc-title">
					{this.props.title}
				</div>
				<div className="desc-body">
					{this.props.body}
				</div>
			</div>
		)
	}
}